# Recherche Pokémon Tactica — adversaires officiels

Recherche du 10 octobre 2026, basée sur Poképédia, enregistrée hors du dépôt.

Ouvrir `adversaires-officiels.html` dans un navigateur : recherche par personnage, Pokémon ou opus, filtre de catégorie, fiches dépliables. La page fonctionne hors ligne ; seuls les liens externes vers Poképédia demandent Internet. Aucun serveur n’est requis.

`adversaires-officiels.md` contient la version texte complète. `equipes.csv` s’ouvre dans un tableur (UTF-8, séparateur point-virgule). `equipes-selectionnees.json` contient la sélection structurée. Les paramètres bruts, snapshots HTML compressés et leurs empreintes permettent de vérifier les citations.

Les variantes et formats sont conservés. Les recommandations de combats mystère sont des propositions de recherche, pas des features ajoutées au jeu. Pour jouer à la candidate Tactica, utiliser directement la ROM GBA dans mGBA ; le panneau d’environnement Codex n’est pas l’émulateur.

Reproduction de l’extraction : extraire `sources-pokepedia.zip` dans `/tmp/pokepedia-research`, installer BeautifulSoup dans un répertoire Python local si nécessaire, puis lancer `extract.py` avec ce répertoire sur PYTHONPATH. `build_report.py` lit les fichiers produits et écrit ce dossier sous `/workspace/artifacts/`. Les scripts ne modifient aucun checkout Git.
