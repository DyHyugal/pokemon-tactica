import json,re,html,csv,hashlib,zipfile,shutil,urllib.parse
from pathlib import Path
src=Path('/tmp/pokepedia-research');out=Path('/workspace/artifacts/recherche-adversaires-officiels');raw=json.loads((src/'teams.json').read_text());profiles=[]
def add(name,source,category,ids,labels,interest,priority='Autre référence',formats=None):
 assert len(ids)==len(labels)
 teams=[]
 for ix,label in zip(ids,labels):
  t=json.loads(json.dumps(raw[source][ix]));t['source_index']=ix;t['label']=label;t['format']=(formats or {}).get(ix,'Solo');teams.append(t)
 profiles.append(dict(name=name,source=source,category=category,teams=teams,interest=interest,priority=priority))
C='Maîtres et figures de la Ligue';R='Rivaux';B='Boss et adversaires spéciaux';D='Conseil 4 Myrtille';F='Meneurs de Zones de Combat'
add('Cynthia','Cynthia',C,[0,2,5,9,10],['Diamant/Perle — Ligue','Platine — revanche','Diamant Étincelant/Perle Scintillante — deuxième revanche','Noir/Blanc — Vaguelone','Noir 2/Blanc 2 — Vaguelone'],'DEPS : Milobellus avec Orbe Flamme/Écaille Spéciale, Togekiss Sérénité et Carchacrok Peau Dure/Danse Lames. Référence directe du combat surprise à Vaguelone.','Priorité mystère')
add('Red','Red',C,[0,1,4],['Or/Argent/Cristal — Mont Argenté','HeartGold/SoulSilver — Mont Argenté',"Let’s Go — Plateau Indigo"],'Référence historique de superboss. Déjà présent dans Tactica : cette fiche sert de comparaison, pas de proposition de nouveau personnage.')
add('Blue','Blue',C,[10,14],['HeartGold/SoulSilver — revanche',"Let’s Go — revanche"],'Les équipes de Champion de RF/VF sont ajoutées dans la fiche complémentaire ci-dessous. Déjà lié à Kanto dans Tactica.')
add('Blue — Champion RF/VF','Blue__Équipes dans Pokémon Rouge Feu et Vert Feuille',C,[24,25,26],['Rouge Feu/Vert Feuille — deuxième Ligue, Dracaufeu','Rouge Feu/Vert Feuille — deuxième Ligue, Tortank','Rouge Feu/Vert Feuille — deuxième Ligue, Florizarre'],'Les variantes sont des équipes complètes alternatives, pas six emplacements interchangeables indépendamment.')
add('Peter','Peter',C,[4,6],['Rouge Feu/Vert Feuille — revanche','HeartGold/SoulSilver — deuxième Ligue'],'HGSS : Drattak, Carchacrok et Dracolosse. Une équipe de référence pour les Dragons ; personnage déjà lié à Johto.')
add('Pierre Rochard','Pierre Rochard',C,[3,2],['Émeraude — Site Météore','Rubis Oméga/Saphir Alpha — deuxième Ligue'],'Méga-Métalosse dans ROSA ; Airmure pose Picots et Kaorine dispose des deux murs.','Priorité mystère')
add('Marc','Marc (Hoenn)',C,[1,4],['Émeraude — Maître de la Ligue','Rubis Oméga/Saphir Alpha — Épisode Delta'],'Émeraude présente la version de Champion la plus élevée de ces deux combats. Milobellus reste sa signature.')
add('Goyah','Goyah',C,[0,2],['Noir/Blanc — Ligue postgame','Noir 2/Blanc 2 — Renouet, mode Challenge'],'Pyrax est sa signature ; l’équipe de Noir/Blanc est plus élevée en niveau que celle de la suite.','Priorité mystère')
add('Iris','Iris (Unys)',C,[2,4],['Noir 2/Blanc 2 — deuxième Ligue, mode Normal','Noir 2/Blanc 2 — deuxième Ligue, mode Challenge'],'En Challenge, Drattak remplace Drakkarmin. Tranchodon est l’ace.','Priorité mystère')
add('Dianthéa','Dianthéa',C,[0,5],['X/Y — Ligue, équipe de six','X/Y — Château de Combat, Faire-part Noir, équipe de quatre'],'Méga-Gardevoir. Le niveau 80 concerne seulement l’équipe de quatre du Château ; ne pas inventer six Pokémon niveau 80.')
add('Tarak','Tarak',C,list(range(7)),['Épée/Bouclier — Match Ultime, variante Pyrobut','Épée/Bouclier — Match Ultime, variante Lézargus','Épée/Bouclier — Match Ultime, variante Gorythmic','Épée/Bouclier — Stade de Winscor, variante Pyrobut','Épée/Bouclier — Stade de Winscor, variante Lézargus','Épée/Bouclier — Stade de Winscor, variante Gorythmic','Épée/Bouclier — Tournoi des Stars, équipe de trois'],'Dracaufeu Gigamax. Les six Pokémon du combat d’histoire, les cinq du Stade et les trois du Tournoi des Stars sont distingués ; ne pas créer une équipe officielle de six au niveau 80.',formats={6:'Duo'})
add('Professeur Euphorbe','Professeur Euphorbe',C,[3,4,5,6,7,8],['Soleil/Lune — défense du titre, Félinferno','Soleil/Lune — défense du titre, Oratoria','Soleil/Lune — défense du titre, Archéduc','Ultra-Soleil/Ultra-Lune — défense du titre, Félinferno','Ultra-Soleil/Ultra-Lune — défense du titre, Oratoria','Ultra-Soleil/Ultra-Lune — défense du titre, Archéduc'],'Figure finale de Soleil/Lune. Le starter change selon le choix du joueur.')
add('Tili','Tili',R,[45,46,47],['Ultra-Soleil/Ultra-Lune — défense du titre, Oratoria','Ultra-Soleil/Ultra-Lune — défense du titre, Archéduc','Ultra-Soleil/Ultra-Lune — défense du titre, Félinferno'],'Raichu d’Alola et un starter d’Alola ; les évolutions d’Évoli varient avec ce starter.')
add('Alisma','Alisma',C,[2],['Écarlate/Violet — Le Disque Indigo, Club de la Ligue'],'Équipe remaniée du DLC : Floréclat en tête, Scalpereur en fin et nouveaux Blindépique/Lanssorien. Beaucoup plus intéressante que sa première équipe de Ligue.')
add('Mustar','Mustar',C,[2,3,4,5],['Épée/Bouclier — Isolarmure, revanche, Shifours Mille Poings','Épée/Bouclier — Isolarmure, revanche, Shifours Poing Final','Épée/Bouclier — Tournoi des Stars, Mille Poings','Épée/Bouclier — Tournoi des Stars, Poing Final'],'Ancien Maître, Shifours Gigamax ; deux formes alternatives. Les niveaux 80 correspondent au format Duo à trois Pokémon.','Priorité mystère',formats={4:'Duo',5:'Duo'})
add('Apia','Apia',B,[2,3],['Épée/Bouclier — Isolarmure, revanche, Tortank','Épée/Bouclier — Isolarmure, revanche, Florizarre'],'Combat secret avec une véritable équipe de six. Tortank ou Florizarre Gigamax selon le choix initial.','Priorité mystère')
add('Timmy','Timmy',R,[7],['Rubis Oméga/Saphir Alpha — ultime revanche, Maison de Combat'],'Méga-Gallame avec Danse Lames ; Azumarill Coloforce, Flambusard Ailes Bourrasque, Carchacrok Peau Dure/Casque Brut et Magnézone Ballon.','Priorité mystère')
add('René / Barry','Barry (Sinnoh)__Équipes dans Pokémon Platine',R,[27,28,29],['Platine — après 20 victoires à la Ligue, Simiabraz','Platine — après 20 victoires à la Ligue, Pingoléon','Platine — après 20 victoires à la Ligue, Torterra'],'Ace niveau 85 ; le palier inutilisé 69–75 a été écarté.')
add('René / Barry — DEPS','René__Équipes dans Pokémon Diamant Étincelant et Perle Scintillante',R,[21,22,23],['DEPS — après 20 victoires à la Ligue, Simiabraz','DEPS — après 20 victoires à la Ligue, Pingoléon','DEPS — après 20 victoires à la Ligue, Torterra'],'Contrairement à Platine, son ace atteint ici 74, pas 85.')
add('Silver','Silver (Johto)__Équipes dans Pokémon Or HeartGold et Argent SoulSilver',R,[21,22,23],['HeartGold/SoulSilver — Plateau Indigo, Typhlosion','HeartGold/SoulSilver — Plateau Indigo, Aligatueur','HeartGold/SoulSilver — Plateau Indigo, Méganium'],'Équipes officielles avec Farfuret et Magnéton : ne pas les transformer en Dimoret/Magnézone en prétendant citer HGSS.')
add('Silver — bonus Stadium','Silver (Johto)',R,[7],['Pokémon Stadium 2 — second round'],'Lugia, Ho-Oh et Mewtwo, tous niveau 100 : bonus d’un jeu secondaire, séparé des équipes de la série principale.')
add('Tcheren','Tcheren__Équipes dans Pokémon Noir et Blanc',R,[27,28,29],['Noir/Blanc — Route Victoire, Roitiflam','Noir/Blanc — Route Victoire, Clamiral','Noir/Blanc — Route Victoire, Majaspic'],'Équipes fixes alternatives selon le starter ; Tranchodon et Gigalithe constituent le noyau commun.')
add('Matis','Matis',R,[30,31,32],['Noir 2/Blanc 2 — Port Yoneuve, Roitiflam','Noir 2/Blanc 2 — Port Yoneuve, Clamiral','Noir 2/Blanc 2 — Port Yoneuve, Majaspic'],'Libégon, Ohmassacre et Frison ; les singes élémentaires sont liés au starter.')
add('Kalem / Serena','Serena',R,[28,29,30],['X/Y — Batisques, Goupelin','X/Y — Batisques, Amphinobi','X/Y — Batisques, Blindépique'],'Méga-Absol ; les mêmes espèces/niveaux sont vérifiés sur la page Kalem, avec la différence de sexe de Mistigrix.')
add('Brice / Flora','Brice (Hoenn)',R,[6,7,8],['Rubis Oméga/Saphir Alpha — Route 103, Braségali','Rubis Oméga/Saphir Alpha — Route 103, Laggron','Rubis Oméga/Saphir Alpha — Route 103, Jungko'],'Dernier duel après le générique : Méga-starter niveau 50, équipe de cinq. Les compositions équivalentes sont vérifiées sur la page Flora ; moins redoutable que Timmy en postgame.')
add('Gladio','Gladio',R,[15,16,17],['Ultra-Soleil/Ultra-Lune — Ligue, Silvallié Feu','Ultra-Soleil/Ultra-Lune — Ligue, Silvallié Eau','Ultra-Soleil/Ultra-Lune — Ligue, Silvallié Plante'],'Nostenfer, Zoroark, Porygon-Z, Lucario et un starter de Kanto accompagnent Silvallié.')
add('Nabil','Nabil__Équipes dans Pokémon Épée et Bouclier',R,list(range(27,33)),['Épée — Sleepwood, Lézargus/Zamazenta','Épée — Sleepwood, Gorythmic/Zamazenta','Épée — Sleepwood, Pyrobut/Zamazenta','Bouclier — Sleepwood, Lézargus/Zacian','Bouclier — Sleepwood, Gorythmic/Zacian','Bouclier — Sleepwood, Pyrobut/Zacian'],'Le légendaire est celui opposé à la version du joueur. Forme armée conservée lorsqu’elle est indiquée par la source.')
add('Menzi','Menzi',R,[21,22,23,24,25,26],['Écarlate/Violet — Épilogue, Palmaval','Écarlate/Violet — Épilogue, Miascarade','Écarlate/Violet — Épilogue, Flâmigator','Écarlate/Violet — Club de la Ligue, Palmaval','Écarlate/Violet — Club de la Ligue, Miascarade','Écarlate/Violet — Club de la Ligue, Flâmigator'],'Le Club et l’Épilogue ont le même niveau maximal, mais des espèces différentes. Au Club : Archéduc, Simiabraz ou Amphinobi remplacent Muplodocus.','Priorité mystère')
add('Kassis','Kassis',R,[10,12],['Écarlate/Violet — Le Disque Indigo, Maître Myrtille','Écarlate/Violet — revanche au Club de la Ligue'],'Tarpaud Crachin, Félinferno Intimidation, Dracolosse, Porygon-Z, Angoliath et Pomdorochi ; référence actuelle de combat Duo.','Priorité mystère',formats={10:'Duo',12:'Duo'})
add('Pepper','Pepper',R,[8],['Écarlate/Violet — Club de la Ligue'],'Dogrino, Gigansel, Crustabri et Terracruel ; version post-DLC au niveau 82–83.')
add('Travis','Travis',R,[5,6],['Épée/Bouclier — Stade de Winscor','Épée/Bouclier — Tournoi des Stars'],'Sorcilence Gigamax ; sa composition plus haute en niveau à trois relève du Duo.',formats={6:'Duo'})
add('N','N',B,[4,5,8,9,10,11],['Noir — Palais, Zekrom','Blanc — Palais, Reshiram','Noir 2/Blanc 2 — printemps, pluie','Noir 2/Blanc 2 — été, soleil','Noir 2/Blanc 2 — automne, sable','Noir 2/Blanc 2 — hiver, grêle'],'Quatre véritables équipes climatiques distinctes en postgame. Référence particulièrement adaptée aux poseurs automatiques/manuels et relais de l’IA HARD.','Priorité mystère')
add('Ghetis','Ghetis',B,[0,1,2,3],['Noir/Blanc — combat final','Noir 2/Blanc 2 — combat final','Ultra-Soleil — Rainbow Rocket, Zekrom','Ultra-Lune — Rainbow Rocket, Reshiram'],'Trioxhydre est sa signature. Le niveau officiel 54 dans NB est inférieur au seuil d’évolution : citation historique, pas règle à copier dans Tactica.')
add('Percupio','Percupio',B,[2,3],['Légendes Pokémon : Arceus — équipe de six','Légendes Pokémon : Arceus — Giratina, deux phases'],'Six Pokémon niveau 68 puis Giratina Alternative et Originelle niveau 70, enchaînés sans guérison intermédiaire. La seconde fiche contient deux phases successives, pas deux Giratina dans une équipe standard.','Priorité mystère',formats={2:'Solo, système LPA',3:'Deux phases successives, système LPA'})
add('Guajava','Guajava',B,[0,2,3,5],['Noir 2 — Tour Noire, mode Normal','Noir 2 — Tour Noire, mode Challenge','Blanc 2 — Arbre Creux Blanc, mode Normal','Blanc 2 — Arbre Creux Blanc, mode Challenge'],'Trois Pokémon seulement : Latios/Carchacrok/Pyrax ou Latias/Dracolosse/Pyrax. Niveaux 85 en Challenge.','Priorité mystère')
add('Giovanni','Giovanni',B,[15,16],['Ultra-Soleil — Rainbow Rocket, Méga-Mewtwo X','Ultra-Lune — Rainbow Rocket, Méga-Mewtwo Y'],'Les formes Méga-Mewtwo sont différentes selon la version ; quatre Pokémon Sol accompagnent l’ace.')
add('Hélio','Hélio',B,[6,7,8],['Platine — Monde Distorsion','Ultra-Soleil — Rainbow Rocket, Dialga','Ultra-Lune — Rainbow Rocket, Palkia'],'Version Rainbow Rocket avec un légendaire ; la version du Monde Distorsion reste un combat d’histoire marquant.')
add('Lysandre','Lysandre',B,[2,3,4,5],['X/Y — dernier combat Team Flare','Ultra-Soleil — Rainbow Rocket, Xerneas','Ultra-Lune — Rainbow Rocket, Yveltal','Légendes Pokémon : Z-A — équipe de six'],'Méga-Léviator ; versions Rainbow Rocket avec un légendaire et version Z-A à six Pokémon. Le système de combat Z-A diffère du tour par tour.')
add('Arthur','Arthur (Team Aqua)',B,[4,6],['Saphir Alpha — Caverne Fondmer','Ultra-Soleil/Ultra-Lune — Rainbow Rocket'],'Sharpedo Méga dans Saphir Alpha ; Kyogre accompagne l’équipe Rainbow Rocket.')
add('Max','Max (Team Magma)',B,[5,7],['Rubis Oméga — Caverne Fondmer','Ultra-Soleil/Ultra-Lune — Rainbow Rocket'],'Camérupt Méga dans Rubis Oméga ; Groudon accompagne l’équipe Rainbow Rocket.')
add('Guzma','Guzma',B,[8],['Ultra-Soleil/Ultra-Lune — défense du titre'],'Cinq Insectes niveau 68, avec Sarmuraï comme signature.')
add('IA d’Olim','Professeure Olim',B,[0,1],['Écarlate — Zone Zéro, équipe Paradoxe','Écarlate — confrontation finale, Koraidon'],'L’adversaire est l’IA d’Olim, pas un duel normal avec la professeure. L’équipe de six puis la phase scénarisée Koraidon sont séparées.',formats={1:'Phase scénarisée imposée'})
add('IA de Turum','Professeur Turum',B,[0,1],['Violet — Zone Zéro, équipe Paradoxe','Violet — confrontation finale, Miraidon'],'L’adversaire est l’IA de Turum. L’équipe de six puis la phase scénarisée Miraidon sont séparées.',formats={1:'Phase scénarisée imposée'})
add('Dhilan','Dhilan',B,[1],['Épée/Bouclier — Couronneige, Grand Antre Dynamax'],'Ancien Maître avec une équipe Acier de cinq Pokémon ; personnage moins attendu qu’un Maître principal.')
add('Irido','Irido',D,[1],['Écarlate/Violet — Myrtille, revanche'],'Duo : Hyporoi Glissade/Danse Pluie, Dracolosse Vent Arrière et Pondralugon Fulgurayon.','Référence Duo',formats={1:'Duo'})
add('Nérine','Nérine',D,[1],['Écarlate/Violet — Myrtille, revanche'],'Duo : Symbios Distorsion, Airmure Piège de Roc/Cyclone et Métalosse.','Référence Duo',formats={1:'Duo'})
add('Rubépin','Rubépin',D,[1],['Écarlate/Violet — Myrtille, revanche'],'Duo : deux utilisateurs de Zénith, Noadkoko Récolte/Lance-Soleil et Braségali Turbo.','Référence Duo',formats={1:'Duo'})
add('Taro','Taro',D,[2],['Écarlate/Violet — Myrtille, revanche'],'Duo : Farfaduvet Farceur/Vent Arrière, Granbull Intimidation et Charmilly Nappage ; Minotaupe est l’ace.','Référence Duo',formats={2:'Duo'})

add('Koner','Koner',F,[1,2,3,4],['Diamant Étincelant/Perle Scintillante — Tour de Combat, 49e combat','DEPS — Tour de Combat, Expert, variante Dracolosse/Heatran/Cresselia','DEPS — Tour de Combat, Expert, variante Regigigas/Dracolosse/Milobellus','DEPS — Tour de Combat, Expert, variante Heatran/Rhinastoc/Dracolosse'],'Trois Pokémon au niveau 50 et une équipe du joueur limitée au même format : la difficulté vient aussi des sets et de la série à tenir. Les équipes Expert restent des variantes distinctes.','Référence de combat')
add('Cathy','Cathy (Tour de Combat)',F,[1,2],['Émeraude — Tour de Combat, symbole Or, niveau adaptatif','Soleil/Lune et Ultra-Soleil/Ultra-Lune — Route 8'],'Émeraude : Raikou, Latios et Ronflex. Poképédia précise le niveau 50 en mode Niveau 50 et 60–100 selon le niveau maximal du joueur en Niveau libre. La notation 50–100 du tableau est une plage de formats, pas un tirage aléatoire.','Priorité mystère')
add('Bayar','Bayar',F,[1],['Émeraude — Pyramide de Combat, symbole Or'],'Artikodin, Électhor et Sulfura. La page Bayar affiche le niveau 100. La page Pyramide de Combat précise cependant 50 en mode Niveau 50, et le niveau du Pokémon le plus élevé du joueur (minimum 60) en Niveau libre : 100 est donc une valeur maximale du tableau, pas un niveau invariant.','Référence de combat')
add('Chammal','Chammal',F,[1,4],['Noir/Blanc et Noir 2/Blanc 2 — Métro Super Solo','Légendes Pokémon : Arceus — Dojo, équipe de six la plus élevée'],'Métro : trois Pokémon niveau 50. LPA : équipe complète culminant à Scorvol 77 ; ces deux systèmes ne sont pas équivalents.','Priorité mystère',formats={4:'Solo, système LPA'})
add('Chamsin','Chamsin',F,[1],['Noir/Blanc et Noir 2/Blanc 2 — Métro Super Duo'],'Quatre Pokémon niveau 50 ; ne pas ajouter les Pokémon du Métro Solo pour fabriquer six membres.','Référence Duo',formats={1:'Duo'})
add('Amaryllis','Amaryllis',B,[1],['Rubis Oméga/Saphir Alpha — Épisode Delta, Pilier Céleste'],'Cinq Dragons, avec Méga-Drattak. Personnage important et inhabituel pour un combat surprise.','Priorité mystère')
add('Green','Green',B,[0],["Let’s Go — Grotte Azurée / revanche"],'Six Pokémon, avec Méga-Tortank. Personnage différent de Blue, malgré les variantes historiques des noms dans certaines langues.','Priorité mystère')

def clean(v):
 if v is None:return None
 v=re.sub(r'<!--.*?-->','',str(v),flags=re.S).strip()
 v=re.sub(r'\{\{Infobulle\|([^|]+)\|.*?\}\}',r'\1',v)
 v=v.replace('{{!}}','|');v=re.sub(r'\[\[([^\]]+)\]\]',lambda m:m.group(1).split('|')[-1],v)
 if '|' in v:v=v.rsplit('|',1)[-1]
 v=re.sub('<[^>]+>',' ',v);v=re.sub(r'\s+',' ',v).strip()
 return v
for p in profiles:
 page=p['source'].replace('__','/').replace(' ','_');p['url']='https://www.pokepedia.fr/'+urllib.parse.quote(page,safe='/(),:')
 for t in p['teams']:
  for k in ['context','game','trainer','condition','starter_player']:t[k]=clean(t.get(k))
  for m in t['members']:
   for k in ['name','form','level','item','ability']:m[k]=clean(m.get(k))
   m['moves']=[clean(v) for v in m['moves']]
   assert m['name'] and m['level'] and re.fullmatch(r'\d+(?:-\d+)?',m['level']), (p['name'],m)
  assert 1<=len(t['members'])<=6

# Preserve exact raw source input separately from cleaned reading fields.
metadata={'consulted_date':'2026-10-10','source':'Poképédia','scope':'Sélection de références de combat : série principale, avec Silver Stadium 2 explicitement séparé','profiles':len(profiles),'battle_variants':sum(len(p['teams']) for p in profiles),'distinct_characters':len({n for p in profiles for n in (['Kalem','Serena'] if p['name']=='Kalem / Serena' else ['Brice','Flora'] if p['name']=='Brice / Flora' else [p['name'].split(' — ')[0].replace(' / Barry','')])}),'repository_changes':'aucune','criterion':'Équipes finales et/ou revanches marquantes par opus ; niveau maximal et format indiqués, sans classement objectif de difficulté.'}
(out/'equipes-selectionnees.json').write_text(json.dumps({'metadata':metadata,'profiles':profiles},ensure_ascii=False,indent=2)+'\n')
shutil.copy(src/'teams.json',out/'extraction-brute-pokepedia.json')
intro='''Recherche consultée le **10 octobre 2026**, exclusivement sur **Poképédia**. Les chiffres ci-dessous sont les niveaux des jeux officiels, pas des caps proposés pour Tactica. Cette sélection rassemble des figures de Ligue, rivaux, superboss et références tactiques ; elle ne prétend pas classer objectivement leur difficulté ni recenser tous les Dresseurs.

Les équipes finales et revanches sont privilégiées. Les variantes liées au starter, à la version, à la saison et au mode Challenge restent séparées. Une équipe Duo de trois au niveau 80 n’est pas présentée comme une équipe Solo de six au même niveau. Les pools aléatoires de Tour de Combat/Arbre de Combat et les duos Masters EX ne servent pas à inventer une équipe canonique de six. Les équipes fixes de meneurs, comme Koner ou Cathy, sont en revanche conservées avec leur format réel.

La liste distingue les Pokémon de base de leurs formes utilisées en combat : Méga-Évolution, Gigamax, formes de Shifours, etc. L’absence d’objet ou de talent dans une table source est indiquée par « — » ; ce n’est pas la preuve que le moteur du jeu n’en définit aucun. Les noms de capacités abrégés de la source sont conservés.
'''
recommendations='''Pour des **combats mystère Tactica**, mes premières pistes sont **Cynthia, Timmy, N, Iris, Pierre Rochard, Goyah, Mustar, Apia, Guajava et Kassis**. Cynthia reprend directement l’idée du visiteur inattendu de Vaguelone. Timmy fournit une revanche déjà construite autour d’une Méga et d’objets compétitifs. N propose quatre identités de climat officielles plutôt qu’une composition inventée. Apia, Mustar et Guajava sont de véritables combats secrets/postgame. Kassis et le Conseil 4 Myrtille sont surtout des références pour le Duo.

**Percupio** est aussi un excellent personnage surprise, mais reproduire son épreuve complète implique un enchaînement de phases : le lister ne signifie pas que cette mécanique existe déjà dans Tactica. **Red** est conservé comme référence historique puisqu’il est déjà présent dans le projet.

Amaryllis, Green et Cathy sont également des options pertinentes pour un visiteur surprise. Aucun personnage, événement, set ou cap de Tactica n’a été modifié. Une éventuelle adaptation devra respecter les règles existantes de stade légal, de caps, d’objets et d’unicité des Méga. Les niveaux illégaux de certains jeux officiels, comme Trioxhydre 54 chez Ghetis, sont des faits historiques à citer, pas des dérogations automatiques pour Tactica. Le Gigamax, la Téracristallisation et les systèmes de LPA/Z-A doivent être distingués des mécaniques effectivement disponibles dans la ROM.
'''
summary=[];md=['# Adversaires officiels — équipes de référence\n',intro,'## Sélection pour les futurs combats mystère\n',recommendations,'## Vue d’ensemble\n','| Personnage | Opus / combat représentatif | Équipe | Source |','|---|---|---|---|']
def member_name(m):return m['name']+(' ('+m['form']+')' if m.get('form') else '')
def team_line(t):return ' · '.join(member_name(m)+' '+m['level'] for m in t['members'])
# Pick the largest roster first, then the highest maximum level. This provides a
# reading shortcut only: full variants remain below, with their actual formats.
for p in profiles:
 t=max(p['teams'],key=lambda t:(len(t['members']),max(max(int(n) for n in re.findall(r'\d+',m['level'])) for m in t['members'])));summary.append((p,t))
 md.append('| '+p['name']+' | '+t['label']+' | '+team_line(t)+' | [Poképédia]('+p['url']+') |')
md.extend(['\n## Fiches et variantes exactes\n'])
for p in profiles:
 md+=['### '+p['name']+'\n',p['interest']+'\n','Source : ['+p['source'].replace('__','/')+']('+p['url']+').\n']
 for t in p['teams']:
  md+=['#### '+t['label']+'\n','Format : **'+t['format']+'**. '+('Starter du joueur indiqué par la source : **'+t['starter_player']+'**.' if t['starter_player'] else '')+'\n','| Pokémon / forme | Niveau | Objet | Talent | Capacités |','|---|---:|---|---|---|']
  for m in t['members']:md.append('| '+member_name(m)+' | '+m['level']+' | '+(m['item'] or '—')+' | '+(m['ability'] or '—')+' | '+' · '.join(v or '—' for v in m['moves'])+' |')
  md.append('')
md+=['## Traçabilité\n','Les pages HTML consultées et leur empreinte SHA-256 sont conservées dans `sources-pokepedia.zip` et `sources-manifest.json`. L’extraction brute des paramètres de leurs tables est dans `extraction-brute-pokepedia.json`. Pour Bayar, le tableau de personnage affiche 100 ; le cadre du lieu est aussi consulté dans [Pyramide de Combat](https://www.pokepedia.fr/Pyramide_de_Combat). Cette page confirme 50 en mode Niveau 50 et max(60, niveau le plus élevé du joueur) en Niveau libre. Le 100 affiché sur la fiche Bayar n’est donc pas invariant. Les fichiers nettoyés facilitent la lecture et ne remplacent pas les pages source. Les références Kalem/Serena et Brice/Flora ont été recoupées sur leurs deux pages. Les lignes inutilisées de Platine ne font pas partie de la sélection.\n']
(out/'adversaires-officiels.md').write_text('\n'.join(md)+'\n')
with (out/'equipes.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.writer(f,delimiter=';');w.writerow(['Personnage','Catégorie','Opus et combat','Format','Starter joueur','Pokémon','Forme','Niveau','Objet','Talent','Capacité 1','Capacité 2','Capacité 3','Capacité 4','Source Poképédia'])
 for p in profiles:
  for t in p['teams']:
   for m in t['members']:w.writerow([p['name'],p['category'],t['label'],t['format'],t['starter_player'],m['name'],m['form'],m['level'],m['item'],m['ability'],*m['moves'],p['url']])
esc=html.escape;cards=[]
for idx,p in enumerate(profiles):
 blocks=[]
 for t in p['teams']:
  rows=''.join('<tr><td>'+esc(member_name(m))+'</td><td>'+esc(m['level'])+'</td><td>'+esc(m['item'] or '—')+'</td><td>'+esc(m['ability'] or '—')+'</td><td>'+esc(' · '.join(v or '—' for v in m['moves']))+'</td></tr>' for m in t['members'])
  blocks.append('<details><summary>'+esc(t['label'])+' <small>('+esc(t['format'])+')</small></summary><div class="scroll"><table><thead><tr><th>Pokémon / forme</th><th>Niv.</th><th>Objet</th><th>Talent</th><th>Capacités</th></tr></thead><tbody>'+rows+'</tbody></table></div></details>')
 rep=summary[idx][1]
 cards.append('<article data-category="'+esc(p['category'],quote=True)+'"><h2>'+esc(p['name'])+'</h2><div class="tags">'+esc(p['category'])+' · '+esc(p['priority'])+'</div><p>'+esc(p['interest'])+'</p><p class="roster">'+esc(rep['label'])+'<br><strong>'+esc(team_line(rep))+'</strong></p>'+''.join(blocks)+'<p><a target="_blank" rel="noreferrer" href="'+esc(p['url'],quote=True)+'">Source Poképédia</a></p></article>')
style='''body{font:16px/1.55 system-ui,sans-serif;background:#101927;color:#e8eff8;margin:0}main{max-width:1150px;margin:auto;padding:32px 20px}h1{font-size:2.1rem}h2{margin-top:0}p{max-width:100ch}a{color:#80d2ff}.controls{position:sticky;top:0;padding:14px;background:#101927;display:flex;gap:10px;flex-wrap:wrap;z-index:1}input,select,button{font:inherit;padding:10px;background:#203149;border:1px solid #64758d;color:#fff;border-radius:6px}input{flex:1;min-width:200px}article{padding:22px;background:#18263a;border:1px solid #344b68;border-radius:10px;margin:18px 0}.tags,small{color:#aabed6}.roster{background:#213650;padding:14px;border-radius:6px}details{margin:9px 0;border-top:1px solid #344b68;padding-top:8px}summary{cursor:pointer}.scroll{overflow:auto}table{width:100%;border-collapse:collapse;font-size:14px}td,th{text-align:left;padding:10px;vertical-align:top;border-bottom:1px solid #344b68}th{color:#93dcff}[hidden]{display:none}.notice{border-left:4px solid #83d6c5;padding-left:16px}'''
js='''const search=document.querySelector('#search'),category=document.querySelector('#category'),cards=[...document.querySelectorAll('article')];const norm=s=>s.normalize('NFD').replace(/[\\u0300-\\u036f]/g,'').toLowerCase();function filter(){let n=0;for(const c of cards){c.hidden=!(norm(c.textContent).includes(norm(search.value))&&(!category.value||c.dataset.category===category.value));if(!c.hidden)n++;}document.querySelector('#count').textContent=n+' fiches affichées';}search.addEventListener('input',filter);category.addEventListener('change',filter);document.querySelector('#expand').addEventListener('click',()=>{for(const c of cards.filter(c=>!c.hidden))for(const d of c.querySelectorAll('details'))d.open=true;});document.querySelector('#collapse').addEventListener('click',()=>{for(const d of document.querySelectorAll('details'))d.open=false;});filter();'''
page='<!doctype html><html lang="fr"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Adversaires officiels — Pokémon Tactica</title><style>'+style+'</style><main><h1>Adversaires officiels · équipes de référence</h1><p>Poképédia consultée le 10 octobre 2026. '+str(len(profiles))+' fiches et '+str(metadata['battle_variants'])+' équipes ou variantes. Aucun changement du dépôt.</p><p class="notice">Les niveaux sont ceux des jeux officiels. Cette sélection compare des équipes finales, des revanches et des références tactiques ; ce n’est pas un classement universel de difficulté. Les formats Solo, Duo et phases de boss sont distingués.</p><p><strong>Premières pistes pour les combats mystère :</strong> Cynthia, Timmy, N, Iris, Pierre Rochard, Goyah, Mustar, Apia, Guajava et Kassis. Percupio nécessite une réflexion séparée sur les phases ; Red est déjà présent dans le projet.</p><p>Les mécaniques Gigamax, Téracristal, LPA et Z-A sont des références officielles à distinguer du runtime Tactica. Aucun set n’a été adapté ici. Les pools aléatoires de combat et les équipes inutilisées ne sont pas transformés en équipes fixes.</p><div class="controls"><input id="search" type="search" aria-label="Rechercher" placeholder="Personnage, Pokémon, climat, jeu…"><select id="category" aria-label="Catégorie"><option value="">Toutes les catégories</option>'+''.join('<option>'+esc(c)+'</option>' for c in [C,R,B,D,F])+'</select><button id="expand">Tout déplier</button><button id="collapse">Tout replier</button><span id="count" aria-live="polite"></span></div>'+''.join(cards)+'<p>Les sources, variantes, objets, talents et capacités sont également conservés dans les fichiers Markdown, CSV et JSON du dossier. Les caractères — signalent une donnée absente de la table citée.</p></main><script>'+js+'</script></html>'
(out/'adversaires-officiels.html').write_text(page)
manifest=[]
with zipfile.ZipFile(out/'sources-pokepedia.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(src.glob('*.html')):
  data=p.read_bytes();z.writestr(p.name,data);manifest.append({'page':p.stem.replace('__','/'),'file':p.name,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
(out/'sources-manifest.json').write_text(json.dumps({'consulted_date':'2026-10-10','pages':manifest},ensure_ascii=False,indent=2)+'\n')
for name in ['extract.py','build_report.py']:shutil.copy(src/name,out/name)
(out/'README.md').write_text('''# Recherche Pokémon Tactica — adversaires officiels

Recherche du 10 octobre 2026, basée sur Poképédia, enregistrée hors du dépôt.

Ouvrir `adversaires-officiels.html` dans un navigateur : recherche par personnage, Pokémon ou opus, filtre de catégorie, fiches dépliables. La page fonctionne hors ligne ; seuls les liens externes vers Poképédia demandent Internet. Aucun serveur n’est requis.

`adversaires-officiels.md` contient la version texte complète. `equipes.csv` s’ouvre dans un tableur (UTF-8, séparateur point-virgule). `equipes-selectionnees.json` contient la sélection structurée. Les paramètres bruts, snapshots HTML compressés et leurs empreintes permettent de vérifier les citations.

Les variantes et formats sont conservés. Les recommandations de combats mystère sont des propositions de recherche, pas des features ajoutées au jeu. Pour jouer à la candidate Tactica, utiliser directement la ROM GBA dans mGBA ; le panneau d’environnement Codex n’est pas l’émulateur.

Reproduction de l’extraction : extraire `sources-pokepedia.zip` dans `/tmp/pokepedia-research`, installer BeautifulSoup dans un répertoire Python local si nécessaire, puis lancer `extract.py` avec ce répertoire sur PYTHONPATH. `build_report.py` lit les fichiers produits et écrit ce dossier sous `/workspace/artifacts/`. Les scripts ne modifient aucun checkout Git.
''')
with zipfile.ZipFile(out.parent/'recherche-adversaires-officiels.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in out.iterdir():
  if p.is_file():z.write(p,'recherche-adversaires-officiels/'+p.name)
print(json.dumps(metadata,ensure_ascii=False));print('Files',[(p.name,p.stat().st_size) for p in out.iterdir()]);print('Saved',out)
