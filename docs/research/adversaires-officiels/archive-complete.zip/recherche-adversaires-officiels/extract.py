import json,re,pathlib
from bs4 import BeautifulSoup,Tag
root=pathlib.Path('/tmp/pokepedia-research');all_teams={}
for p in sorted(root.glob('*.html')):
 soup=BeautifulSoup(p.read_text(),'html.parser');body=soup.select_one('#mw-content-text') or soup.select_one('.mw-parser-output');headings={};teams=[]
 for e in body.descendants:
  if not isinstance(e,Tag):continue
  if re.fullmatch(r'h[2-6]',e.name):
   rank=int(e.name[1]);headings={k:v for k,v in headings.items() if k<rank};headings[rank]=e.get_text(' ',strip=True)
  if not e.has_attr('data-mw'):continue
  try:d=json.loads(e['data-mw'])
  except Exception:continue
  for part in d.get('parts',[]):
   if not isinstance(part,dict) or 'template' not in part:continue
   params={k:v.get('wt','').strip() for k,v in part['template'].get('params',{}).items()}
   if 'p1-nom' not in params:continue
   members=[]
   for i in range(1,7):
    name=params.get(f'p{i}-nom');level=params.get(f'p{i}-niveau')
    if name:members.append({'name':name,'form':params.get(f'p{i}-forme'),'level':level,'item':params.get(f'p{i}-objet'),'ability':params.get(f'p{i}-talent'),'moves':[params.get(f'p{i}-capacité{j}') for j in range(1,5)]})
   teams.append({'context':' > '.join(headings.values()),'game':params.get('jeu'),'trainer':params.get('d-nom'),'condition':params.get('condition'),'starter_player':params.get('pokémon-départ'),'members':members})
 all_teams[p.stem]=teams
(root/'teams.json').write_text(json.dumps(all_teams,ensure_ascii=False,indent=2))
for name,teams in all_teams.items():
 print(name,len(teams))
